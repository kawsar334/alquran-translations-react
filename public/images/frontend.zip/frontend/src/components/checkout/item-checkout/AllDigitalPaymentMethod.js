import React from "react";

const AllDigitalPaymentMethod = () => {
  return <div>AllDigitalPaymentMethod</div>;
};

export default AllDigitalPaymentMethod;
