import React from "react";
import { Stack } from "@mui/system";

const CustomScrollBar = ({ popOverHeightHandler }) => {
  return <Stack sx={{}}></Stack>;
};

export default CustomScrollBar;
